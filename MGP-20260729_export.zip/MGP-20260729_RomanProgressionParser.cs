﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using UnityEngine;
using static MidiGenPlay.MusicTheory.MusicTheory;

namespace MidiGenPlay.Composition
{
    /// <summary>
    /// Result of parsing a Roman chord token from a progression string.
    /// - degree: scale degree (0..6, Tonic..LeadingTone)
    /// - explicitQuality: if not null, this quality is "fixed" by the string
    ///   (via suffix or case). If null, caller may infer diatonic quality.
    /// - durationMeasures: duration in *measures* for this chord.
    /// </summary>
    /// <summary>
    /// EDITOR-CASE-1. Letter-case of a token's Roman core, captured for
    /// every parsed chord regardless of parse mode so downstream resolution
    /// (ChordQualityResolver) can honor the author's case under auto-diatonic
    /// modes instead of silently discarding it. Mixed case is a typo smell:
    /// the resolver ignores it and the editor warns.
    /// </summary>
    public enum RomanCaseHint
    {
        None = 0,   // rests / not applicable
        Lower = 1,  // "iv" — minor-family intent
        Upper = 2,  // "IV" — major-family intent
        Mixed = 3,  // "Iv" — ambiguous; discarded with a warning
    }

    [Serializable]
    public struct ParsedChord
    {
        public ScaleDegree degree;
        public ChordQuality? explicitQuality;
        public float durationMeasures;
        public bool isRest;
        public int degreeAccidental; // -1 = flat, 0 = none, +1 = sharp

        /// <summary>
        /// EDITOR-CASE-1. Case of the Roman core, always populated (append-
        /// only field; default None keeps every pre-existing construction
        /// site valid). Informational when explicitQuality is already set by
        /// a suffix — suffix always wins.
        /// </summary>
        public RomanCaseHint caseHint;

        public ParsedChord(
            ScaleDegree degree,
            ChordQuality? explicitQuality,
            float durationMeasures,
            bool isRest = false,
            int degreeAccidental = 0,
            RomanCaseHint caseHint = RomanCaseHint.None)
        {
            this.degree = degree;
            this.explicitQuality = explicitQuality;
            this.durationMeasures = durationMeasures;
            this.isRest = isRest;
            this.degreeAccidental = degreeAccidental;
            // EDITOR-CASE-1: a struct with an explicit constructor must
            // assign EVERY field (CS0171). Optional + defaulted to None so
            // every pre-existing call site keeps compiling unchanged.
            this.caseHint = caseHint;
        }

        public static ParsedChord MakeRest(float durationMeasures)
        {
            return new ParsedChord(
                ScaleDegree.Tonic, // arbitrary, unused when isRest == true
                null,
                durationMeasures,
                true);
        }
    }

    /// <summary>
    /// Pure Roman progression parser. Converts strings like:
    ///   "I – V – vi – IV"
    ///   "iiø7 (0.5) – V7 (0.5) – I (1)"
    /// into a list of ParsedChord entries.
    /// 
    /// It does NOT know about tonality or diatonic inference. It only:
    /// - parses the Roman numeral → ScaleDegree
    /// - parses optional quality suffix → explicit ChordQuality
    /// - optionally interprets case as explicit triad quality
    ///   (e.g. "ii" → minor, "V" → major) when enabled.
    /// - parses duration in measures.
    /// </summary>
    public sealed class RomanProgressionParser
    {
        /// <summary>
        /// Main entry point.
        /// </summary>
        /// <param name="input">Full Roman progression string.</param>
        /// <param name="defaultMeasuresPerChord">
        /// Duration in measures to use when a chord has no explicit duration.
        /// </param>
        /// <param name="inferTriadFromCaseWhenNoSuffix">
        /// If true, and no quality suffix is given, lowercase roman → Minor,
        /// uppercase → Major (triads). If false, case is ignored and no
        /// explicit quality is set in that situation.
        /// </param>
        public bool TryParse(
            string input,
            float defaultMeasuresPerChord,
            bool inferTriadFromCaseWhenNoSuffix,
            out List<ParsedChord> chords,
            out string error)
        {
            chords = new List<ParsedChord>();

            if (string.IsNullOrWhiteSpace(input))
            {
                error = "Input string is empty.";
                return false;
            }

            // Allow multi-line input; treat newlines as spaces.
            input = input.Replace('\n', ' ');

            // Split by dash / en dash / em dash: "I – V – vi – IV"
            string[] tokens = input
                .Split(new[] { '–', '-', '—' }, StringSplitOptions.RemoveEmptyEntries);

            foreach (var raw in tokens)
            {
                var token = raw.Trim();
                if (string.IsNullOrEmpty(token))
                    continue;

                // pattern: "I", "I (2)", "V7", "iiø7 (0.5)", etc.
                string romanPart = token;
                string durPart = null;

                int paren = token.IndexOf('(');
                if (paren >= 0)
                {
                    romanPart = token.Substring(0, paren).Trim();
                    durPart = token.Substring(paren).Trim(); // "(2)" or "(0.5)"
                }

                // ---------- NEW: rest detection ----------
                bool isRestToken = false;
                if (string.IsNullOrWhiteSpace(romanPart))
                {
                    isRestToken = true; // e.g. "(0.5)"
                }
                else
                {
                    string upper = romanPart.ToUpperInvariant();
                    if (upper == "S" || upper == "REST" || upper == "R")
                        isRestToken = true;
                }

                if (!TryParseDuration(
                        durPart,
                        defaultMeasuresPerChord,
                        out float dur,
                        out var durErr))
                {
                    error = durErr;
                    return false;
                }

                if (isRestToken)
                {
                    // Silent duration, no degree / quality
                    chords.Add(ParsedChord.MakeRest(dur));
                    continue;
                }
                // ---------- end rest detection ----------

                if (!TryParseRomanWithQuality(
                        romanPart,
                        inferTriadFromCaseWhenNoSuffix,
                        out var degree,
                        out var explicitQ,
                        out var accidental,
                        out var tokenCaseHint,
                        out var degErr))
                {
                    error = degErr;
                    return false;
                }

                var pc = new ParsedChord
                {
                    degree = degree,
                    explicitQuality = explicitQ,
                    durationMeasures = dur,
                    isRest = false,
                    degreeAccidental = accidental,
                    caseHint = tokenCaseHint
                };
                chords.Add(pc);
            }

            if (chords.Count == 0)
            {
                error = "No valid chords found in the input.";
                return false;
            }

            error = null;
            return true;
        }

        /// <summary>
        /// Parses the Roman part + optional quality suffix into:
        /// - degree (ScaleDegree)
        /// - optional explicit quality (ChordQuality?)
        /// </summary>
        private bool TryParseRomanWithQuality(
            string token,
            bool inferTriadFromCaseWhenNoSuffix,
            out ScaleDegree degree,
            out ChordQuality? explicitQuality,
            out int degreeAccidental,
            out RomanCaseHint caseHint,
            out string error)
        {
            degree = ScaleDegree.Tonic;
            explicitQuality = null;
            degreeAccidental = 0;
            caseHint = RomanCaseHint.None;
            error = null;

            if (string.IsNullOrWhiteSpace(token))
            {
                error = "Empty chord token.";
                return false;
            }

            token = token.Trim();

            // Split: roman core (I/V/X letters) + whatever remains as quality suffix
            int idx = 0;

            // 1) Optional leading accidental: b / ♭ / # / ♯
            if (idx < token.Length)
            {
                char c = token[idx];
                if (c == 'b' || c == '♭')
                {
                    degreeAccidental = -1;
                    idx++;
                }
                else if (c == '#' || c == '♯')
                {
                    degreeAccidental = +1;
                    idx++;
                }
            }

            // 2) Now parse the Roman core starting at 'idx' (I, ii, V, etc.)
            int startRoman = idx;
            while (idx < token.Length && "IVXivx".IndexOf(token[idx]) >= 0)
                idx++;

            if (idx == startRoman)
            {
                error = $"Expected Roman numeral in '{token}'.";
                degree = ScaleDegree.Tonic;
                explicitQuality = null;
                degreeAccidental = 0;
                return false;
            }

            string romanCore = token.Substring(startRoman, idx - startRoman);
            string suffix = token.Substring(idx); // may be empty, "7", "maj7", "ø7", etc.

            // --- Roman → degree index (0..6) ---
            if (!TryParseRomanToDegreeIndex(romanCore, out int degIndex))
            {
                error = $"Unsupported roman numeral '{romanCore}' in token '{token}'.";
                return false;
            }
            degree = (ScaleDegree)degIndex;

            // --- Quality from suffix (optional, highest priority) ---
            suffix = suffix.Trim();
            bool hasExplicitFromSuffix = false;

            if (!string.IsNullOrEmpty(suffix) &&
                TryParseQualitySuffix(suffix, out var qFromSuffix))
            {
                explicitQuality = qFromSuffix;
                hasExplicitFromSuffix = true;
            }

            // --- EDITOR-CASE-1: always capture the Roman core's case ------
            // The hint travels on ParsedChord so auto-diatonic resolution can
            // honor unambiguous case (suffix > case > auto precedence) instead
            // of silently discarding it. Behavior below (converting case to an
            // explicit triad) is UNCHANGED and still gated on the flag: in
            // None mode the case remains a hard explicit quality.
            {
                bool anyLower = romanCore.Any(ch => char.IsLetter(ch) && char.IsLower(ch));
                bool anyUpper = romanCore.Any(ch => char.IsLetter(ch) && char.IsUpper(ch));

                if (anyLower && anyUpper)
                    caseHint = RomanCaseHint.Mixed;
                else if (anyLower)
                    caseHint = RomanCaseHint.Lower;
                else if (anyUpper)
                    caseHint = RomanCaseHint.Upper;

                // --- Optionally, infer triad from case if no suffix ---
                //   "ii" → minor
                //   "V"  → major
                // Mixed case → ignore and leave null.
                if (!hasExplicitFromSuffix && inferTriadFromCaseWhenNoSuffix)
                {
                    if (caseHint == RomanCaseHint.Lower)
                        explicitQuality = ChordQuality.Minor;
                    else if (caseHint == RomanCaseHint.Upper)
                        explicitQuality = ChordQuality.Major;
                }
            }

            return true;
        }

        /// <summary>
        /// Parses classic roman numerals I..VII to a degree index (0..6).
        /// Case is ignored.
        /// </summary>
        private bool TryParseRomanToDegreeIndex(string roman, out int index)
        {
            index = 0;
            roman = roman.Trim().ToUpperInvariant();

            switch (roman)
            {
                case "I": index = 0; return true;
                case "II": index = 1; return true;
                case "III": index = 2; return true;
                case "IV": index = 3; return true;
                case "V": index = 4; return true;
                case "VI": index = 5; return true;
                case "VII": index = 6; return true;
                default:
                    return false;
            }
        }

        /// <summary>
        /// Maps common chord notation suffixes (7, maj7, M7, m7, dim, °, ø7, sus2, sus4, etc.)
        /// to the internal ChordQuality enum.
        /// </summary>
        private bool TryParseQualitySuffix(string suffix, out ChordQuality quality)
        {
            // Default – will be ignored if we return false
            quality = ChordQuality.Major;

            if (string.IsNullOrWhiteSpace(suffix))
                return false;

            // Normalize: remove spaces, to lower, replace some unicode aliases
            string s = suffix.Replace(" ", "")
                             .Replace("Δ", "maj")
                             .Replace("∆", "maj")
                             .ToLowerInvariant();

            switch (s)
            {
                // --- Triads (major) ---
                case "":
                case "maj":
                case "ma":
                case "mjr":
                case "mja":
                    quality = ChordQuality.Major;
                    return true;

                // Minor triad
                case "m":
                case "min":
                case "mi":
                case "mn":
                case "-":
                case "min3":
                case "mtri":
                case "mtriad":
                    quality = ChordQuality.Minor;
                    return true;

                case "dim":
                case "o":
                case "°":
                    quality = ChordQuality.Diminished;
                    return true;

                case "aug":
                case "+":
                case "+5":
                    quality = ChordQuality.Augmented;
                    return true;

                // --- Sevenths ---
                case "7":
                case "dom":
                case "dom7":
                    quality = ChordQuality.Dominant7;
                    return true;

                case "maj7":
                case "ma7":
                case "m7+":
                case "mm7":
                case "mmaj7":
                    quality = ChordQuality.Major7;
                    return true;

                case "m7":
                case "-7":
                case "min7":
                    quality = ChordQuality.Minor7;
                    return true;

                case "ø":
                case "ø7":
                case "m7b5":
                case "min7b5":
                    quality = ChordQuality.HalfDiminished7;
                    return true;

                case "dim7":
                case "o7":
                case "°7":
                    quality = ChordQuality.Diminished7;
                    return true;

                // --- Suspended / other ---
                case "sus2":
                    quality = ChordQuality.Sus2;
                    return true;

                case "sus4":
                case "sus":
                    quality = ChordQuality.Sus4;
                    return true;

                // --- Sixths (v2 Tier A) ---
                case "6":
                    quality = ChordQuality.Major6;
                    return true;

                case "m6":
                case "min6":
                    quality = ChordQuality.Minor6;
                    return true;

                // --- Suspended dominant (v2 Tier A) ---
                case "7sus4":
                    quality = ChordQuality.Dominant7sus4;
                    return true;

                // --- Ninths (v2 Tier B) ---
                case "9":
                case "dom9":
                    quality = ChordQuality.Dominant9;
                    return true;

                case "maj9":
                case "ma9":
                    quality = ChordQuality.Major9;
                    return true;

                case "m9":
                case "min9":
                    quality = ChordQuality.Minor9;
                    return true;

                default:
                    // Unknown: let caller fall back to diatonic inference.
                    Debug.LogWarning(
                        $"[RomanProgressionParser] Unrecognized chord quality suffix '{suffix}'. " +
                        "Falling back to diatonic / default quality.");
                    return false;
            }
        }

        /// <summary>
        /// Parses a duration token into measures.
        /// - rawDur can be null/empty (use default)
        /// - or something like "(2)", "(0.5)" or just "2"
        /// Durations are in *measures*.
        /// </summary>
        private bool TryParseDuration(
            string rawDur,
            float defaultMeasuresPerChord,
            out float duration,
            out string error)
        {
            error = null;

            // Sensible default if somebody configured 0 or negative
            if (defaultMeasuresPerChord <= 0f)
                defaultMeasuresPerChord = 1f;

            // No explicit duration → use default
            if (string.IsNullOrWhiteSpace(rawDur))
            {
                duration = defaultMeasuresPerChord;
                return true;
            }

            // Clean up string
            string s = rawDur.Trim();

            // Accept "(2)" or "(0.5)" as well as plain "2"
            if (s.StartsWith("(") && s.EndsWith(")"))
            {
                if (s.Length <= 2)
                {
                    error = $"Malformed duration '{rawDur}'. " +
                        "Expected something like '(2)' or '(0.5)'.";
                    duration = 0f;
                    return false;
                }

                s = s.Substring(1, s.Length - 2).Trim();
            }
            else if (s.StartsWith("(") || s.EndsWith(")"))
            {
                // One parenthesis but not the other → clearly a typo
                error = $"Malformed duration '{rawDur}'. Expected '(number)'.";
                duration = 0f;
                return false;
            }

            // Use invariant culture so 0.5 always works
            if (!float.TryParse(
                    s,
                    NumberStyles.Float,
                    CultureInfo.InvariantCulture,
                    out duration))
            {
                error = $"Could not parse duration '{rawDur}'. " +
                    "Use a number like '(2)' or '(0.5)' with a dot as decimal separator.";
                duration = 0f;
                return false;
            }

            if (duration <= 0f)
            {
                error = $"Duration must be > 0 in '{rawDur}'.";
                duration = 0f;
                return false;
            }

            return true;
        }
    }
}