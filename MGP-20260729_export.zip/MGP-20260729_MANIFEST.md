﻿# MGP-20260729 - MidiGenPlay mirror manifest

Exported: 2026-07-29 08:28
Source root: `D:\Projects\MidiGenPlay\MidiGenPlay`
Set: `mgp-export_session-b.txt`

READ-ONLY MIRROR. Authority lives in the MidiGenPlay package.
Anything in the consuming PK NOT prefixed MGP-20260729 is older than this export.

| Exported name | Source path | Last write | Bytes | SHA256 |
|---|---|---|---|---|
| MGP-20260729_Especificacion_Contenido_FaseA.md | `Documentation~\planning\Especificacion_Contenido_FaseA.md` | 2026-07-28 17:33 | 16455 | 03803249AB61 |
| MGP-20260729_SSoT_Authoring_Chord_Progressions.md | `Documentation~\authoring\SSoT_Authoring_Chord_Progressions.md` | 2026-07-28 14:22 | 26466 | 7B356CCE2DD5 |
| MGP-20260729_SSoT_Authoring_Rhythm_Patterns.md | `Documentation~\authoring\SSoT_Authoring_Rhythm_Patterns.md` | 2026-07-24 09:25 | 21791 | 4F32C65E9B40 |
| MGP-20260729_SSoT_Composer_Backing_Track.md | `Documentation~\runtime\SSoT_Composer_Backing_Track.md` | 2026-07-28 14:22 | 49325 | E0D65F5E2904 |
| MGP-20260729_SSoT_Composer_Bass_Track.md | `Documentation~\runtime\SSoT_Composer_Bass_Track.md` | 2026-07-28 14:22 | 35297 | 76C222313B41 |
| MGP-20260729_CURRENT_STATE.md | `Documentation~\CURRENT_STATE.md` | 2026-07-28 14:22 | 91486 | 85B86F216FCC |
| MGP-20260729_SSoT_INDEX.md | `Documentation~\SSoT_INDEX.md` | 2026-07-24 09:25 | 3866 | 95ACC817A770 |
| MGP-20260729_RomanProgressionParser.cs | `Runtime\CoreScripts\Composition\RomanProgressionParser.cs` | 2026-07-27 11:36 | 20128 | 830017C43582 |
| MGP-20260729_DrumPatternTextParser.cs | `Editor\DrumPatternTextParser.cs` | 2026-05-22 20:39 | 15417 | 3B010CE96766 |
| MGP-20260729_ChordProgressionData.cs | `Runtime\CoreScripts\Data\ChordProgressionData.cs` | 2026-07-27 11:09 | 15609 | 52F30BB90B4B |
| MGP-20260729_MIDIInstrumentSO.cs | `Runtime\CoreScripts\ScriptableObjects\MIDIInstrumentSO.cs` | 2025-11-25 18:06 | 1227 | 2B6449BDDB5E |

## Not found (check the set list)
- `Documentation~/planning/Handoff_Contenido_FaseB_ALWTTT.md`
