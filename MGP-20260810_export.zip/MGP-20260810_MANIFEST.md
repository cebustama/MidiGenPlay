﻿# MGP-20260810 - MidiGenPlay mirror manifest

Exported: 2026-08-10 10:13
Source root: `D:\Projects\MidiGenPlay\MidiGenPlay`
Set: `mgp-export_pk-mirror.txt`

READ-ONLY MIRROR. Authority lives in the MidiGenPlay package.
Anything in the consuming PK NOT prefixed MGP-20260810 is older than this export.

| Exported name | Source path | Last write | Bytes | SHA256 |
|---|---|---|---|---|
| MGP-20260810_CURRENT_STATE.md | `Documentation~\CURRENT_STATE.md` | 2026-08-08 19:23 | 103388 | B6DAE83C9C60 |
| MGP-20260810_SSoT_INDEX.md | `Documentation~\SSoT_INDEX.md` | 2026-07-24 09:25 | 3866 | 95ACC817A770 |
| MGP-20260810_SSoT_CONTRACTS.md | `Documentation~\SSoT_CONTRACTS.md` | 2026-08-08 19:22 | 8654 | ACFA59142C00 |
| MGP-20260810_coverage-matrix.md | `Documentation~\coverage-matrix.md` | 2026-08-08 19:23 | 33061 | A8A56C53B0DB |
| MGP-20260810_changelog-ssot.md | `Documentation~\changelog-ssot.md` | 2026-08-08 19:23 | 211846 | 812AB02B676C |
| MGP-20260810_PENDING_DOC_DIFFS.md | `Documentation~\planning\PENDING_DOC_DIFFS.md` | 2026-08-08 19:23 | 11017 | 14B5DE6EEFA9 |
| MGP-20260810_package.json | `package.json` | 2026-07-21 13:49 | 375 | A4A5B6D574D6 |
| MGP-20260810_ssot_manifest.yaml | `Documentation~\ssot_manifest.yaml` | 2026-08-08 19:23 | 174476 | F1B3255CCB59 |
| MGP-20260810_SSoT_Runtime_Generation_Orchestration.md | `Documentation~\runtime\SSoT_Runtime_Generation_Orchestration.md` | 2026-08-05 18:54 | 26617 | 00E33AF7970A |
| MGP-20260810_SSoT_Runtime_Song_Model_and_Config.md | `Documentation~\runtime\SSoT_Runtime_Song_Model_and_Config.md` | 2026-07-21 13:49 | 6477 | B63515D7D394 |
| MGP-20260810_SSoT_Composer_Backing_Track.md | `Documentation~\runtime\SSoT_Composer_Backing_Track.md` | 2026-08-08 19:22 | 59397 | 304BD64BFA48 |
| MGP-20260810_SSoT_Composer_Bass_Track.md | `Documentation~\runtime\SSoT_Composer_Bass_Track.md` | 2026-08-05 18:53 | 53303 | BDEB7A1E95F9 |
| MGP-20260810_SSoT_Composer_Rhythm_Track.md | `Documentation~\runtime\SSoT_Composer_Rhythm_Track.md` | 2026-07-26 23:58 | 15936 | 48668BC06317 |
| MGP-20260810_SSoT_Composer_Melody_Track.md | `Documentation~\runtime\SSoT_Composer_Melody_Track.md` | 2026-08-08 19:22 | 23595 | 1DF134D2E6E3 |
| MGP-20260810_SSoT_Authoring_Chord_Progressions.md | `Documentation~\authoring\SSoT_Authoring_Chord_Progressions.md` | 2026-08-05 18:54 | 35061 | D32687B22568 |
| MGP-20260810_SSoT_Authoring_Rhythm_Patterns.md | `Documentation~\authoring\SSoT_Authoring_Rhythm_Patterns.md` | 2026-07-24 09:25 | 21791 | 4F32C65E9B40 |
| MGP-20260810_SSoT_Authoring_Tools.md | `Documentation~\authoring\SSoT_Authoring_Tools.md` | 2026-07-25 14:04 | 22493 | 1000BE53226F |
| MGP-20260810_SSoT_Authoring_Melody_Composition.md | `Documentation~\authoring\SSoT_Authoring_Melody_Composition.md` | 2026-08-08 19:22 | 28645 | 703971C9220B |
| MGP-20260810_SSoT_CompositionCards_TrackStyleBundles.md | `Documentation~\reference\cross-project\ALWTTT\SSoT_CompositionCards_TrackStyleBundles.md` | 2026-08-05 18:55 | 19536 | A50FC18CC892 |
| MGP-20260810_SSoT_Runtime_CompositionSession_Bridge.md | `Documentation~\reference\cross-project\ALWTTT\SSoT_Runtime_CompositionSession_Bridge.md` | 2026-03-19 12:46 | 10855 | DB688409F965 |
| MGP-20260810_SSoT_CompositionSystem_INDEX.md | `Documentation~\reference\cross-project\ALWTTT\SSoT_CompositionSystem_INDEX.md` | 2026-04-14 16:52 | 1954 | F771E758D2A6 |
| MGP-20260810_ALWTTT_Melody_Authoring_Pipeline.md | `Documentation~\reference\cross-project\ALWTTT\ALWTTT_Melody_Authoring_Pipeline.md` | 2026-03-18 13:58 | 8209 | 0F08F44F5B46 |
| MGP-20260810_Handoff_MGP_BAGGAGE_1.md | `Documentation~\reference\cross-project\ALWTTT\Handoff_MGP_BAGGAGE_1.md` | 2026-07-21 13:49 | 15733 | 15BD2E1851C7 |
| MGP-20260810_Handoff_MGP_POCKET.md | `Documentation~\reference\cross-project\ALWTTT\Handoff_MGP_POCKET.md` | 2026-07-27 00:03 | 5895 | 681B107B9EFF |
| MGP-20260810_Handoff_MGP_MIX_1.md | `Documentation~\reference\cross-project\ALWTTT\Handoff_MGP_MIX_1.md` | 2026-07-21 13:49 | 6436 | DB79F6C1589B |
| MGP-20260810_BasslineCardConfigSO.cs | `Runtime\CoreScripts\Composition\Data\BasslineCardConfigSO.cs` | 2026-08-06 09:19 | 26960 | A39E118B055C |
| MGP-20260810_BackingCardConfigSO.cs | `Runtime\CoreScripts\Composition\Data\BackingCardConfigSO.cs` | 2026-08-08 18:19 | 10673 | D9BC9FBB58EC |
| MGP-20260810_RhythmCardConfigSO.cs | `Runtime\CoreScripts\Composition\Data\RhythmCardConfigSO.cs` | 2026-07-16 21:21 | 6514 | F4C0D3AE471A |
| MGP-20260810_MelodyCardConfigSO.cs | `Runtime\CoreScripts\Composition\Data\MelodyCardConfigSO.cs` | 2026-06-21 20:55 | 1529 | A14237B3E6CA |
| MGP-20260810_HarmonyCardConfigSO.cs | `Runtime\CoreScripts\Composition\Data\HarmonyCardConfigSO.cs` | 2025-11-13 16:46 | 313 | 471C7EE23D34 |
| MGP-20260810_TrackStyleBundleSO.cs | `Runtime\CoreScripts\Composition\Data\TrackStyleBundleSO.cs` | 2025-11-12 14:13 | 460 | 2AAA4D5805D7 |
| MGP-20260810_ITrackComposer.cs | `Runtime\CoreScripts\Composition\Interfaces\ITrackComposer.cs` | 2025-10-26 21:09 | 613 | AE5338ED7551 |
| MGP-20260810_ChordExpressionType.cs | `Runtime\CoreScripts\Composition\Data\ChordExpressionType.cs` | 2026-07-24 18:11 | 10405 | C7CE32D487E3 |
| MGP-20260810_ModulationOctaveHint.cs | `Runtime\CoreScripts\Composition\Data\ModulationOctaveHint.cs` | 2026-05-22 12:53 | 717 | 4F18271C9BC3 |
| MGP-20260810_VoiceLeadingConfig.cs | `Runtime\CoreScripts\Composition\Data\VoiceLeadingConfig.cs` | 2025-10-02 15:54 | 3748 | F4349B20AD8D |
| MGP-20260810_ChordProgressionPaletteSO.cs | `Runtime\CoreScripts\Composition\Data\ChordProgressionPaletteSO.cs` | 2026-03-07 00:52 | 3429 | C260E6C20073 |
| MGP-20260810_DrumPatternPaletteSO.cs | `Runtime\CoreScripts\Composition\Data\DrumPatternPaletteSO.cs` | 2026-05-29 21:06 | 4595 | F9F57A8322C1 |
| MGP-20260810_ChordProgressionData.cs | `Runtime\CoreScripts\Data\ChordProgressionData.cs` | 2026-07-27 11:09 | 15609 | 52F30BB90B4B |
| MGP-20260810_DrumPatternData.cs | `Runtime\CoreScripts\Data\DrumPatternData.cs` | 2026-05-24 13:08 | 9071 | A5C75858999E |
| MGP-20260810_MelodyPatternData.cs | `Runtime\CoreScripts\Data\MelodyPatternData.cs` | 2026-06-16 20:13 | 6190 | 4EAF099298B0 |
| MGP-20260810_PatternDataSO.cs | `Runtime\CoreScripts\Data\PatternDataSO.cs` | 2025-12-01 23:51 | 294 | 6056F504A94F |
| MGP-20260810_ChordProgressionLibrarySO.cs | `Runtime\CoreScripts\Composition\Data\ChordProgressionLibrarySO.cs` | 2025-12-01 16:48 | 2087 | CA2DFA713973 |
| MGP-20260810_TonalityProfileSO.cs | `Runtime\CoreScripts\Data\TonalityProfileSO.cs` | 2025-11-16 14:56 | 5805 | B4019E6E4CD0 |
| MGP-20260810_PhrasePaletteSO.cs | `Runtime\CoreScripts\Composition\Data\Phrases\PhrasePaletteSO.cs` | 2026-08-05 14:46 | 1116 | 8DC8A004CA47 |
| MGP-20260810_PhraseArchetypeSO.cs | `Runtime\CoreScripts\Composition\Data\Phrases\PhraseArchetypeSO.cs` | 2025-11-10 18:49 | 569 | DAA237CB5C89 |
| MGP-20260810_MelodicLeadingConfig.cs | `Runtime\CoreScripts\Composition\Data\MelodicLeadingConfig.cs` | 2026-08-05 14:46 | 2356 | B164831E7D08 |
| MGP-20260810_MelodicStyleSO.cs | `Runtime\CoreScripts\Composition\Data\MelodicStyleSO.cs` | 2026-08-05 14:45 | 6673 | 4B4B8CB9A76F |
| MGP-20260810_MidiGenPlayConfig.cs | `Runtime\CoreScripts\Data\MidiGenPlayConfig.cs` | 2026-05-08 23:25 | 5961 | DD1FA5515D66 |
| MGP-20260810_PatternRepositoryResources.cs | `Runtime\CoreScripts\Services\PatternRepositoryResources.cs` | 2026-05-08 23:26 | 4231 | 5781142AE093 |
| MGP-20260810_TrackPatternConfigStoreResources.cs | `Runtime\CoreScripts\Services\TrackPatternConfigStoreResources.cs` | 2026-07-05 17:30 | 7602 | DB80EA2C705D |
| MGP-20260810_IPatternRepository.cs | `Runtime\CoreScripts\Interfaces\IPatternRepository.cs` | 2025-10-01 13:23 | 796 | 1D121C941F0C |
| MGP-20260810_ITrackPatternConfigStore.cs | `Runtime\CoreScripts\Interfaces\ITrackPatternConfigStore.cs` | 2025-09-02 21:45 | 1856 | D411D4C96A7E |
| MGP-20260810_InstrumentRepositoryResources.cs | `Runtime\CoreScripts\Services\InstrumentRepositoryResources.cs` | 2025-10-01 18:21 | 2488 | 1CD410B3D554 |
| MGP-20260810_ChordProgressionRuntimeImporter.cs | `Runtime\CoreScripts\Composition\ChordProgressionRuntimeImporter.cs` | 2026-07-29 11:45 | 40251 | D5A9A54E6D12 |
| MGP-20260810_RomanProgressionParser.cs | `Runtime\CoreScripts\Composition\RomanProgressionParser.cs` | 2026-07-27 11:36 | 20128 | 830017C43582 |
| MGP-20260810_ChordQualityResolver.cs | `Runtime\CoreScripts\Composition\ChordQualityResolver.cs` | 2026-07-27 11:12 | 8254 | 1C4CEFC86803 |
| MGP-20260810_ChordProgressionRequality.cs | `Runtime\CoreScripts\Composition\ChordProgressionRequality.cs` | 2026-07-27 11:10 | 23286 | 5E3C5EA2931B |
| MGP-20260810_DrumPatternTextParser.cs | `Editor\DrumPatternTextParser.cs` | 2026-05-22 20:39 | 15417 | 3B010CE96766 |
| MGP-20260810_SongOrchestrator.cs | `Runtime\CoreScripts\Composition\SongOrchestrator.cs` | 2026-08-05 14:48 | 78400 | 748E0D170CC4 |
| MGP-20260810_CompositionReadback.cs | `Runtime\CoreScripts\Composition\CompositionReadback.cs` | 2026-08-05 14:47 | 8339 | 7BB3F9294E24 |
| MGP-20260810_SongConfig.cs | `Runtime\CoreScripts\Data\SongConfig.cs` | 2026-07-06 13:07 | 6115 | 5B8AA86DF289 |
| MGP-20260810_BassTrackComposer.cs | `Runtime\CoreScripts\Composition\Composers\BassTrackComposer.cs` | 2026-08-06 09:19 | 104018 | EE9D0B7A1A25 |
| MGP-20260810_PitchBendWriter.cs | `Runtime\CoreScripts\Composition\Articulation\PitchBendWriter.cs` | 2026-08-03 21:01 | 11779 | C79467606BC2 |
| MGP-20260810_MIDIInstrumentSO.cs | `Runtime\CoreScripts\ScriptableObjects\MIDIInstrumentSO.cs` | 2025-11-25 18:06 | 1227 | 2B6449BDDB5E |
| MGP-20260810_MIDIPercussionInstrumentSO.cs | `Runtime\CoreScripts\ScriptableObjects\MIDIPercussionInstrumentSO.cs` | 2025-01-11 14:09 | 2693 | CE5A914EE567 |
| MGP-20260810_Especificacion_Contenido_FaseA.md | `Documentation~\planning\Especificacion_Contenido_FaseA.md` | 2026-07-28 17:33 | 16455 | 03803249AB61 |

## Not found (check the set list)
- `MGP-TRIAGE-ALWTTT-R3_host_resolutions.md`
- `TrackRole.cs`
- `Handoff_Contenido_FaseB_ALWTTT.md`
